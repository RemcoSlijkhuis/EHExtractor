/**
 * Contains a custom log handler that directs log output to the Ghidra script console.
 */
package loggingbridge;