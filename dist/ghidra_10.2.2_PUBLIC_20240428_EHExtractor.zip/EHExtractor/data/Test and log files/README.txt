Test files for the EHExtractor script/analyzer with corresponding output log files.

